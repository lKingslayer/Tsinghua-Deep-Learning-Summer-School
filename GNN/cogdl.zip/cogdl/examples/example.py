import numpy as np
import torch

from cogdl.data import Data
from cogdl.datasets import build_dataset
from cogdl.models import build_model
from cogdl.tasks import build_task
from cogdl.utils import build_args_from_dict


class CustomDataset:
    def __init__(self, data):
        self.data = data
        self.num_features = data.x.shape[1]
        self.num_classes = torch.max(self.data.y).item() + 1


def get_default_args():
    cuda_available = torch.cuda.is_available()
    default_dict = {'hidden_size': 16,
                    'dropout': 0.5,
                    'patience': 100,
                    'max_epoch': 500,
                    'cpu': not cuda_available,
                    'lr': 0.01,
                    'weight_decay': 5e-4}
    return build_args_from_dict(default_dict)

def construct_random_dataset():

    # preprocess your data
    # TODO
	
    x = torch.from_numpy(np.random.randn(10, 16)).float()
    edge_index = torch.from_numpy(np.random.randint(10, size=(2, 20))).long()
    #edge_attr = torch.from_numpy(np.random.randn(20)).float()
    y = torch.from_numpy(np.random.randint(2, size=10)).long()
    #data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=y)
    data = Data(x=x, edge_index=edge_index, y=y)

    data.train_mask = torch.zeros(10, dtype=torch.bool)
    data.train_mask[[0, 1, 2, 3, 4, 5]] = True
    data.val_mask = torch.zeros(10, dtype=torch.bool)
    data.val_mask[[6, 7]] = True
    data.test_mask = torch.zeros(10, dtype=torch.bool)
    data.test_mask[[8, 9]] = True

    custom_dataset = CustomDataset(data)

    return custom_dataset

if __name__ == "__main__":

    # set args
    args = get_default_args()

    # set a task
    args.task = 'node_classification'

    # set a model
    args.model = 'gcn'

    # construct your dataset
    dataset = construct_random_dataset()

    args.num_features = dataset.num_features
    args.num_classes = dataset.num_classes

    # set your model layers
    args.num_layers = 2

    model = build_model(args)
    task = build_task(args, dataset=dataset, model=model)
    ret = task.train()
