Tasks of CogDL
==============

CogDL now supports the following tasks:
- unsupervised node classification
- semi-supervised node classification
- heterogeneous node classification
- link prediction
- multiplex link prediction
- unsupervised graph classification
- supervised graph classification
- community detection
- social influence prediction
