tasks package
=============

Submodules
----------

tasks.base\_task module
-----------------------

.. automodule:: tasks.base_task
    :members:
    :undoc-members:
    :show-inheritance:

tasks.community\_detection module
---------------------------------

.. automodule:: tasks.community_detection
    :members:
    :undoc-members:
    :show-inheritance:

tasks.graph\_classification module
----------------------------------

.. automodule:: tasks.graph_classification
    :members:
    :undoc-members:
    :show-inheritance:

tasks.influence\_maximization module
------------------------------------

.. automodule:: tasks.influence_maximization
    :members:
    :undoc-members:
    :show-inheritance:

tasks.link\_prediction module
-----------------------------

.. automodule:: tasks.link_prediction
    :members:
    :undoc-members:
    :show-inheritance:

tasks.multiplex\_link\_prediction module
----------------------------------------

.. automodule:: tasks.multiplex_link_prediction
    :members:
    :undoc-members:
    :show-inheritance:

tasks.multiplex\_node\_classification module
--------------------------------------------

.. automodule:: tasks.multiplex_node_classification
    :members:
    :undoc-members:
    :show-inheritance:

tasks.node\_classification module
---------------------------------

.. automodule:: tasks.node_classification
    :members:
    :undoc-members:
    :show-inheritance:

tasks.node\_classification\_sampling module
-------------------------------------------

.. automodule:: tasks.node_classification_sampling
    :members:
    :undoc-members:
    :show-inheritance:

tasks.unsupervised\_graph\_classification module
------------------------------------------------

.. automodule:: tasks.unsupervised_graph_classification
    :members:
    :undoc-members:
    :show-inheritance:

tasks.unsupervised\_node\_classification module
-----------------------------------------------

.. automodule:: tasks.unsupervised_node_classification
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: tasks
    :members:
    :undoc-members:
    :show-inheritance:
