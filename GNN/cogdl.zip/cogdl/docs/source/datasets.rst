datasets package
================

Submodules
----------

datasets.edgelist\_label module
-------------------------------

.. automodule:: datasets.edgelist_label
    :members:
    :undoc-members:
    :show-inheritance:

datasets.edgelist\_label\_type module
-------------------------------------

.. automodule:: datasets.edgelist_label_type
    :members:
    :undoc-members:
    :show-inheritance:

datasets.gatne module
---------------------

.. automodule:: datasets.gatne
    :members:
    :undoc-members:
    :show-inheritance:

datasets.matlab\_matrix module
------------------------------

.. automodule:: datasets.matlab_matrix
    :members:
    :undoc-members:
    :show-inheritance:

datasets.pyg module
-------------------

.. automodule:: datasets.pyg
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: datasets
    :members:
    :undoc-members:
    :show-inheritance:
