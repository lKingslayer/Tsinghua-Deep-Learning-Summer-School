Tasks
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   node_classification
   unsupervised_node_classification
   supervised_graph_classification
   unsupervised_graph_classification

