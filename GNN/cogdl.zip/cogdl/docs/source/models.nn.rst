models.nn package
=================

Submodules
----------

models.nn.fastgcn module
------------------------

.. automodule:: models.nn.fastgcn
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.gat module
--------------------

.. automodule:: models.nn.gat
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.gcn module
--------------------

.. automodule:: models.nn.gcn
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.gin module
--------------------

.. automodule:: models.nn.gin
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.graphsage module
--------------------------

.. automodule:: models.nn.graphsage
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.infograph module
--------------------------

.. automodule:: models.nn.infograph
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.mixhop module
-----------------------

.. automodule:: models.nn.mixhop
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.mlp module
--------------------

.. automodule:: models.nn.mlp
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.pyg\_cheb module
--------------------------

.. automodule:: models.nn.pyg_cheb
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.pyg\_drgat module
---------------------------

.. automodule:: models.nn.pyg_drgat
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.pyg\_drgcn module
---------------------------

.. automodule:: models.nn.pyg_drgcn
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.pyg\_gat module
-------------------------

.. automodule:: models.nn.pyg_gat
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.pyg\_gcn module
-------------------------

.. automodule:: models.nn.pyg_gcn
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.pyg\_infomax module
-----------------------------

.. automodule:: models.nn.pyg_infomax
    :members:
    :undoc-members:
    :show-inheritance:

models.nn.pyg\_unet module
--------------------------

.. automodule:: models.nn.pyg_unet
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: models.nn
    :members:
    :undoc-members:
    :show-inheritance:
