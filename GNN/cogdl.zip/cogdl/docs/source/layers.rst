layers package
==============

Submodules
----------

layers.maggregator module
-------------------------

.. automodule:: layers.maggregator
    :members:
    :undoc-members:
    :show-inheritance:

layers.mixhop\_layer module
---------------------------

.. automodule:: layers.mixhop_layer
    :members:
    :undoc-members:
    :show-inheritance:

layers.se\_layer module
-----------------------

.. automodule:: layers.se_layer
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: layers
    :members:
    :undoc-members:
    :show-inheritance:
