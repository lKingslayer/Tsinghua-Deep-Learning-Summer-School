data package
============

Submodules
----------

data.batch module
-----------------

.. automodule:: data.batch
    :members:
    :undoc-members:
    :show-inheritance:

data.data module
----------------

.. automodule:: data.data
    :members:
    :undoc-members:
    :show-inheritance:

data.dataloader module
----------------------

.. automodule:: data.dataloader
    :members:
    :undoc-members:
    :show-inheritance:

data.dataset module
-------------------

.. automodule:: data.dataset
    :members:
    :undoc-members:
    :show-inheritance:

data.download module
--------------------

.. automodule:: data.download
    :members:
    :undoc-members:
    :show-inheritance:

data.extract module
-------------------

.. automodule:: data.extract
    :members:
    :undoc-members:
    :show-inheritance:

data.in\_memory\_dataset module
-------------------------------

.. automodule:: data.in_memory_dataset
    :members:
    :undoc-members:
    :show-inheritance:

data.makedirs module
--------------------

.. automodule:: data.makedirs
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: data
    :members:
    :undoc-members:
    :show-inheritance:
